ExpressJs + Passport.js + MySQL Authentication
===========================
An authentication system using passportjs and mysql as the data storage for the users, while using expressjs module to facilitate the routing.