package org.meshpoint.anode.bridge;

/*
 * NOTE that this is a stub class only.
 */

import org.meshpoint.anode.idl.InterfaceManager;

public class Env {
	public static Env getCurrent() {return (Env)null;}
	public InterfaceManager getInterfaceManager() {return (InterfaceManager)null;}
}
