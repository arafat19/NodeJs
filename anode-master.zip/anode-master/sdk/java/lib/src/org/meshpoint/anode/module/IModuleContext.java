package org.meshpoint.anode.module;

public interface IModuleContext {
	public Object getModuleExports();
	public long getEventThreadId();
}
