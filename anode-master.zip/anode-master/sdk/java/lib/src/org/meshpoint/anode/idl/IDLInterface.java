package org.meshpoint.anode.idl;

/*
 * NOTE that this is a stub class only.
 */

public class IDLInterface {}
