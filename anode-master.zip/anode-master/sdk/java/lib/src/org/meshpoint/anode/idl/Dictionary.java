package org.meshpoint.anode.idl;

public interface Dictionary {}
