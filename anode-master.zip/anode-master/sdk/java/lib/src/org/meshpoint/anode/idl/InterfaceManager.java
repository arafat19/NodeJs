package org.meshpoint.anode.idl;

/*
 * NOTE that this is a stub class only.
 */

public class InterfaceManager {
	public synchronized IDLInterface getByName(String name) {return (IDLInterface)null;}	
	public synchronized IDLInterface getByClass(Class<?> javaClass) {return (IDLInterface)null;}
}
