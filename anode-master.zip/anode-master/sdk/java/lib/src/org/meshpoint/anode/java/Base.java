package org.meshpoint.anode.java;

/*
 * NOTE that this is a stub class only.
 */

import org.meshpoint.anode.idl.IDLInterface;

public class Base {
	protected Base(IDLInterface iface) {}
}
