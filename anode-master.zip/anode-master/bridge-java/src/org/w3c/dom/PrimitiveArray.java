package org.w3c.dom;

public interface PrimitiveArray extends Array {

}
